import { RolNombre } from '../../roles/enums/rol-nombre.enum';

export interface JwtPayload {
  sub: number;
  nombreUsuario: string;
  rol: RolNombre;
}