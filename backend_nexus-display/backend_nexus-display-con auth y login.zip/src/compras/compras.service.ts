import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreateCompraDto } from './dto/create-compra.dto';
import { UpdateCompraDto } from './dto/update-compra.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Compra } from './entities/compra.entity';
import { DataSource, Repository } from 'typeorm';
import { DetalleCompra } from '../detalles-compra/entities/detalle-compra.entity';
import { InventarioAlmacen } from '../inventario-almacen/entities/inventario-almacen.entity';
import { Pantalla } from '../pantallas/entities/pantalla.entity';

@Injectable()
export class ComprasService {
  constructor(
    @InjectRepository(Compra) private comprasRepository: Repository<Compra>,
    private dataSource: DataSource,
  ) {}

  async create(createCompraDto: CreateCompraDto): Promise<Compra> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      let totalCompra = 0;

      const compra = new Compra();
      compra.idProveedor = createCompraDto.idProveedor;
      compra.idUsuario = createCompraDto.idUsuario;
      compra.idAlmacen = createCompraDto.idAlmacen;
      compra.total = 0;
      const compraGuardada = await queryRunner.manager.save(Compra, compra);

      for (const item of createCompraDto.detalles) {
        const pantalla = await queryRunner.manager.findOneBy(Pantalla, {
          id: item.idPantalla,
        });
        if (!pantalla) {
          throw new NotFoundException(
            `La pantalla con id ${item.idPantalla} no existe`,
          );
        }

        const subtotal = Number(
          (item.cantidad * item.costoUnitario).toFixed(2),
        );
        totalCompra += subtotal;

        const detalle = new DetalleCompra();
        detalle.idCompra = compraGuardada.id;
        detalle.idPantalla = item.idPantalla;
        detalle.cantidad = item.cantidad;
        detalle.costoUnitario = item.costoUnitario;
        detalle.subtotal = subtotal;
        await queryRunner.manager.save(DetalleCompra, detalle);

        // Sumar el stock al almacén seleccionado
        let inventario = await queryRunner.manager.findOneBy(
          InventarioAlmacen,
          {
            idPantalla: item.idPantalla,
            idAlmacen: createCompraDto.idAlmacen,
          },
        );

        if (!inventario) {
          inventario = new InventarioAlmacen();
          inventario.idPantalla = item.idPantalla;
          inventario.idAlmacen = createCompraDto.idAlmacen;
          inventario.cantidad = item.cantidad;
        } else {
          inventario.cantidad += item.cantidad;
        }

        await queryRunner.manager.save(InventarioAlmacen, inventario);
      }

      compraGuardada.total = Number(totalCompra.toFixed(2));
      await queryRunner.manager.save(Compra, compraGuardada);

      await queryRunner.commitTransaction();
      return this.findOne(compraGuardada.id);
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  async findAll(): Promise<Compra[]> {
    return this.comprasRepository.find({
      relations: {
        proveedor: true,
        usuario: true,
        almacen: true,
        detalles: { pantalla: true },
      },
      order: { id: 'DESC' },
    });
  }

  async findOne(id: number): Promise<Compra> {
    const compra = await this.comprasRepository.findOne({
      where: { id },
      relations: {
        proveedor: true,
        usuario: true,
        almacen: true,
        detalles: { pantalla: true },
      },
    });
    if (!compra) throw new NotFoundException('La compra no existe');
    return compra;
  }

  async update(id: number, updateCompraDto: UpdateCompraDto): Promise<Compra> {
    const compra = await this.findOne(id);
    Object.assign(compra, updateCompraDto);
    return this.comprasRepository.save(compra);
  }

  async remove(id: number): Promise<Compra> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const compra = await this.findOne(id);

      for (const detalle of compra.detalles) {
        const inventario = await queryRunner.manager.findOneBy(
          InventarioAlmacen,
          {
            idPantalla: detalle.idPantalla,
            idAlmacen: compra.idAlmacen,
          },
        );

        if (!inventario || inventario.cantidad < detalle.cantidad) {
          throw new BadRequestException(
            'No se puede eliminar la compra porque el stock de las pantallas ya fue vendido',
          );
        }

        inventario.cantidad -= detalle.cantidad;
        await queryRunner.manager.save(InventarioAlmacen, inventario);
      }

      const eliminada = await queryRunner.manager.softRemove(Compra, compra);
      await queryRunner.commitTransaction();
      return eliminada;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
