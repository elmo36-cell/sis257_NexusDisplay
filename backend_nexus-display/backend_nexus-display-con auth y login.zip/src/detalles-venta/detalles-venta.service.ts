import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateDetalleVentaDto } from './dto/create-detalle-venta.dto';
import { UpdateDetalleVentaDto } from './dto/update-detalle-venta.dto';
import { DetalleVenta } from './entities/detalle-venta.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class DetallesVentaService {
  constructor(
    @InjectRepository(DetalleVenta)
    private detallesVentaRepository: Repository<DetalleVenta>,
  ) {}

  async create(createDetalleVentaDto: CreateDetalleVentaDto): Promise<DetalleVenta> {
    const detalleVenta = new DetalleVenta();
    Object.assign(detalleVenta, createDetalleVentaDto);
    detalleVenta.subtotal = Number(
      (createDetalleVentaDto.cantidad * createDetalleVentaDto.precioUnitario).toFixed(2),
    );
    return this.detallesVentaRepository.save(detalleVenta);
  }

  async findAll(): Promise<DetalleVenta[]> {
    return this.detallesVentaRepository.find({
      relations: { venta: true, pantalla: true },
    });
  }

  async findOne(id: number): Promise<DetalleVenta> {
    const detalleVenta = await this.detallesVentaRepository.findOne({
      where: { id },
      relations: { venta: true, pantalla: true },
    });
    if (!detalleVenta) throw new NotFoundException('El detalle de venta no existe');
    return detalleVenta;
  }

  async update(id: number, updateDetalleVentaDto: UpdateDetalleVentaDto): Promise<DetalleVenta> {
    const detalleVenta = await this.findOne(id);
    Object.assign(detalleVenta, updateDetalleVentaDto);
    detalleVenta.subtotal = Number(
      (detalleVenta.cantidad * detalleVenta.precioUnitario).toFixed(2),
    );
    return this.detallesVentaRepository.save(detalleVenta);
  }

  async remove(id: number): Promise<DetalleVenta> {
    const detalleVenta = await this.findOne(id);
    return this.detallesVentaRepository.softRemove(detalleVenta);
  }
}
