import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Pantalla } from './entities/pantalla.entity';
import { CreatePantallaDto } from './dto/create-pantalla.dto';
import { UpdatePantallaDto } from './dto/update-pantalla.dto';

@Injectable()
export class PantallasService {
  constructor(
    @InjectRepository(Pantalla)
    private pantallasRepository: Repository<Pantalla>,
  ) {}

  async create(createPantallaDto: CreatePantallaDto): Promise<Pantalla> {
    let pantalla = await this.pantallasRepository.findOneBy({
      codigo: createPantallaDto.codigo,
    });
    if (pantalla) throw new ConflictException('La pantalla ya existe');

    pantalla = new Pantalla();
    Object.assign(pantalla, createPantallaDto);
    return this.pantallasRepository.save(pantalla);
  }

  async findCatalogoWeb() {
    const pantallas = await this.pantallasRepository.find({
      relations: {
        modelo: { marca: true },
        calidad: true,
        categoria: true,
        inventarios: { almacen: true },
      },
      order: { id: 'DESC' },
    });

    return pantallas.map((p) => {
      const stockTotal =
        p.inventarios?.reduce((acc, inv) => acc + inv.cantidad, 0) || 0;
      return {
        id: p.id,
        codigo: p.codigo,
        nombre: p.nombre,
        fotografia: p.fotografia,
        precioVenta: p.precioVenta,
        color: p.color,
        conMarco: p.conMarco,
        stockTotal,
        enStock: stockTotal > 0,
        marca: p.modelo?.marca?.nombre ?? '',
        modelo: p.modelo?.nombre ?? '',
        calidad: p.calidad?.nombre ?? '',
        categoria: p.categoria?.nombre ?? '',
        almacenesDisponibles:
          p.inventarios
            ?.filter((inv) => inv.cantidad > 0)
            .map((inv) => ({
              idAlmacen: inv.idAlmacen,
              almacen: inv.almacen?.nombre,
              cantidad: inv.cantidad,
            })) ?? [],
      };
    });
  }

  async findAll(): Promise<Pantalla[]> {
    return this.pantallasRepository.find({
      relations: {
        modelo: { marca: true },
        calidad: true,
        categoria: true,
        inventarios: { almacen: true },
      },
    });
  }

  async findOne(id: number): Promise<Pantalla> {
    const pantalla = await this.pantallasRepository.findOne({
      where: { id },
      relations: {
        modelo: { marca: true },
        calidad: true,
        categoria: true,
        inventarios: { almacen: true },
      },
    });
    if (!pantalla) throw new NotFoundException('La pantalla no existe');
    return pantalla;
  }

  async update(
    id: number,
    updatePantallaDto: UpdatePantallaDto,
  ): Promise<Pantalla> {
    const pantalla = await this.findOne(id);
    Object.assign(pantalla, updatePantallaDto);
    return this.pantallasRepository.save(pantalla);
  }

  async remove(id: number): Promise<Pantalla> {
    const pantalla = await this.findOne(id);
    return this.pantallasRepository.softRemove(pantalla);
  }
}
