import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';
import { RolNombre } from '../enums/rol-nombre.enum';

export class CreateRolDto {
  @ApiProperty({ enum: RolNombre })
  @IsNotEmpty({ message: 'El nombre es obligatorio' })
  @IsEnum(RolNombre, { message: 'El rol debe ser ADMIN, VENDEDOR o CLIENTE' })
  @Transform(({ value }): string | undefined =>
    typeof value == 'string' ? value.trim() : value,
  )
  readonly nombre: RolNombre;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString({ message: 'La descripción debe ser de tipo cadena' })
  @MaxLength(255, {
    message: 'La descripción no puede tener más de 255 caracteres',
  })
  @Transform(({ value }): string | undefined =>
    typeof value == 'string' ? value.trim() : value,
  )
  readonly descripcion?: string;
}
