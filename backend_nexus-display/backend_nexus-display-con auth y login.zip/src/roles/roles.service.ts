import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreateRolDto } from './dto/create-rol.dto';
import { UpdateRolDto } from './dto/update-rol.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Rol } from './entities/rol.entity';
import { Repository } from 'typeorm';
import { RolNombre } from './enums/rol-nombre.enum';

@Injectable()
export class RolesService {
  constructor(
    @InjectRepository(Rol) private rolesRepository: Repository<Rol>,
  ) {}

  async onModuleInit() {
    const rolesIniciales = [
      { nombre: RolNombre.ADMIN, descripcion: 'Administrador del sistema' },
      { nombre: RolNombre.VENDEDOR, descripcion: 'Vendedor de tienda' },
      { nombre: RolNombre.CLIENTE, descripcion: 'Cliente del catálogo web' },
    ];
    for (const item of rolesIniciales) {
      const existe = await this.rolesRepository.findOneBy({
        nombre: item.nombre,
      });
      if (!existe) {
        const nuevo = new Rol();
        Object.assign(nuevo, item);
        await this.rolesRepository.save(nuevo);
      }
    }
  }

  async create(createRolDto: CreateRolDto): Promise<Rol> {
    let rol = await this.rolesRepository.findOneBy({
      nombre: createRolDto.nombre,
    });
    if (rol) throw new ConflictException('El rol ya existe');

    rol = new Rol();
    Object.assign(rol, createRolDto);
    return this.rolesRepository.save(rol);
  }

  async findAll(): Promise<Rol[]> {
    return this.rolesRepository.find();
  }

  async findOne(id: number): Promise<Rol> {
    const rol = await this.rolesRepository.findOneBy({ id });
    if (!rol) throw new NotFoundException('El rol no existe');
    return rol;
  }

  async update(id: number, updateRolDto: UpdateRolDto): Promise<Rol> {
    const rol = await this.findOne(id);
    Object.assign(rol, updateRolDto);
    return this.rolesRepository.save(rol);
  }

  async remove(id: number): Promise<Rol> {
    const rol = await this.findOne(id);
    return this.rolesRepository.softRemove(rol);
  }
}
