import { BeforeInsert, BeforeUpdate, Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { Rol } from '../../roles/entities/rol.entity';
import { Compra } from '../../compras/entities/compra.entity';
import { Venta } from '../../ventas/entities/venta.entity';
import * as bcrypt from 'bcrypt';

@Entity('usuarios')
export class Usuario {
  @PrimaryGeneratedColumn('identity')
  id: number;

  @Column('int', { name: 'id_rol' })
  idRol: number;

  @Column('varchar', { length: 100, unique: true, name: 'nombre_usuario' })
  nombreUsuario: string;

  @Column('varchar',{ length: 100, unique: true })
  correo: string;

  @Column('varchar',{ length: 255, select: false })
  clave: string;

  @Column('boolean',{ default: true })
  activo: boolean;

  @CreateDateColumn({ name: 'fecha_creacion' })
  fechaCreacion: Date;

  @UpdateDateColumn({ name: 'fecha_modificacion' })
  fechaModificacion: Date;

  @DeleteDateColumn({ name: 'fecha_eliminacion' })
  fechaEliminacion: Date;

  @ManyToOne(() => Rol, (rol) => rol.usuarios, { eager: true, onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'id_rol', referencedColumnName: 'id' })
  rol: Rol;

  @OneToMany(() => Compra, compras => compras.usuario)
  compras: Compra[];

  @OneToMany(() => Venta, ventas => ventas.usuario)
  ventas: Venta[];

  @BeforeInsert()
  @BeforeUpdate()
  async encriptarClave() {
    if (this.clave && !this.clave.startsWith('$2b$')) {
      const salt = await bcrypt.genSalt(10);
      this.clave = await bcrypt.hash(this.clave, salt);
    }
  }
}
