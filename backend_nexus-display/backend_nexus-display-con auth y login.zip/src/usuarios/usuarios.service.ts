import { ConflictException, Injectable, NotFoundException, OnModuleInit } from '@nestjs/common';
import { CreateUsuarioDto } from './dto/create-usuario.dto';
import { UpdateUsuarioDto } from './dto/update-usuario.dto';
import { Usuario } from './entities/usuario.entity';
import { Rol } from '../roles/entities/rol.entity';
import { RolNombre } from '../roles/enums/rol-nombre.enum';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class UsuariosService implements OnModuleInit {
  constructor(
    @InjectRepository(Usuario) private usuariosRepository: Repository<Usuario>,
    @InjectRepository(Rol) private rolesRepository: Repository<Rol>,
  ) {}

  // Crea automáticamente los usuarios base al iniciar el servidor
  async onModuleInit() {
    const rolesIniciales = [
      { nombre: RolNombre.ADMIN, descripcion: 'Administrador del sistema' },
      { nombre: RolNombre.VENDEDOR, descripcion: 'Vendedor de tienda' },
      { nombre: RolNombre.CLIENTE, descripcion: 'Cliente del catálogo web' },
    ];

    for (const item of rolesIniciales) {
      let rol = await this.rolesRepository.findOneBy({ nombre: item.nombre });
      if (!rol) {
        rol = new Rol();
        Object.assign(rol, item);
        await this.rolesRepository.save(rol);
      }
    }

    const rolAdmin = await this.rolesRepository.findOneBy({ nombre: RolNombre.ADMIN });
    const rolVendedor = await this.rolesRepository.findOneBy({ nombre: RolNombre.VENDEDOR });
    const rolCliente = await this.rolesRepository.findOneBy({ nombre: RolNombre.CLIENTE });

    const usuariosSemilla = [
      {
        idRol: rolAdmin!.id,
        nombreUsuario: 'admin',
        correo: 'admin@nexusdisplay.com',
        clave: process.env.DEFAULT_PASSWORD || '123456',
      },
      {
        idRol: rolVendedor!.id,
        nombreUsuario: 'vendedor',
        correo: 'vendedor@nexusdisplay.com',
        clave: process.env.DEFAULT_PASSWORD || '123456',
      },
      {
        idRol: rolCliente!.id,
        nombreUsuario: 'cliente',
        correo: 'cliente@nexusdisplay.com',
        clave: process.env.DEFAULT_PASSWORD || '123456',
      },
    ];

    for (const u of usuariosSemilla) {
      const existe = await this.usuariosRepository.findOneBy({ nombreUsuario: u.nombreUsuario });
      if (!existe) {
        const nuevo = new Usuario();
        Object.assign(nuevo, u);
        await this.usuariosRepository.save(nuevo);
      }
    }
  }

  async create(createUsuarioDto: CreateUsuarioDto): Promise<Usuario> {
    let usuario = await this.usuariosRepository.findOneBy({
      nombreUsuario: createUsuarioDto.nombreUsuario,
    });
    if (usuario) throw new ConflictException('El usuario ya existe');

    usuario = new Usuario();
    Object.assign(usuario, createUsuarioDto);
    const guardado = await this.usuariosRepository.save(usuario);
    delete (guardado as any).clave;
    return guardado;
  }

  async findAll(): Promise<Usuario[]> {
    return this.usuariosRepository.find({ relations: { rol: true } });
  }

  async findOne(id: number): Promise<Usuario> {
    const usuario = await this.usuariosRepository.findOne({
      where: { id },
      relations: { rol: true },
    });
    if (!usuario) throw new NotFoundException('El usuario no existe');
    return usuario;
  }

  async validateUser(nombreUsuario: string): Promise<Usuario | null> {
    return this.usuariosRepository
      .createQueryBuilder('usuario')
      .addSelect('usuario.clave')
      .leftJoinAndSelect('usuario.rol', 'rol')
      .where('usuario.nombreUsuario = :nombreUsuario', { nombreUsuario })
      .getOne();
  }

  async update(id: number, updateUsuarioDto: UpdateUsuarioDto): Promise<Usuario> {
    const usuario = await this.findOne(id);
    Object.assign(usuario, updateUsuarioDto);
    const actualizado = await this.usuariosRepository.save(usuario);
    delete (actualizado as any).clave;
    return actualizado;
  }

  async remove(id: number): Promise<Usuario> {
    const usuario = await this.findOne(id);
    return this.usuariosRepository.softRemove(usuario);
  }
}