import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { CreateVentaDto } from './dto/create-venta.dto';
import { UpdateVentaDto } from './dto/update-venta.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Venta } from './entities/venta.entity';
import { DataSource, Repository } from 'typeorm';
import { Pantalla } from '../pantallas/entities/pantalla.entity';
import { InventarioAlmacen } from '../inventario-almacen/entities/inventario-almacen.entity';
import { DetalleVenta } from '../detalles-venta/entities/detalle-venta.entity';

@Injectable()
export class VentasService {
  constructor(
    @InjectRepository(Venta) private ventasRepository: Repository<Venta>,
    private dataSource: DataSource,
  ) {}

  async create(createVentaDto: CreateVentaDto, idUsuarioToken?: number): Promise<Venta> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      let totalVenta = 0;

      const venta = new Venta();
      venta.idUsuario = createVentaDto.idUsuario ?? idUsuarioToken ?? 1;
      venta.idAlmacen = createVentaDto.idAlmacen;
      venta.nombreCliente = createVentaDto.nombreCliente ?? 'S/N';
      venta.documentoCliente = createVentaDto.documentoCliente ?? '0';
      venta.total = 0;
      const ventaGuardada = await queryRunner.manager.save(Venta, venta);

      for (const item of createVentaDto.detalles) {
        const pantalla = await queryRunner.manager.findOneBy(Pantalla, {
          id: item.idPantalla,
        });
        if (!pantalla) {
          throw new NotFoundException(`La pantalla con id ${item.idPantalla} no existe`);
        }

        const inventario = await queryRunner.manager.findOne(InventarioAlmacen, {
          where: {
            idPantalla: item.idPantalla,
            idAlmacen: createVentaDto.idAlmacen,
          },
          lock: { mode: 'pessimistic_write' },
        });

        if (!inventario || inventario.cantidad < item.cantidad) {
          const disponible = inventario ? inventario.cantidad : 0;
          throw new BadRequestException(
            `Stock insuficiente para "${pantalla.nombre}". Disponible: ${disponible}, solicitado: ${item.cantidad}`,
          );
        }

        // Descontar del inventario del almacén
        inventario.cantidad -= item.cantidad;
        await queryRunner.manager.save(InventarioAlmacen, inventario);

        // Si no se envía precioUnitario en el detalle, usa el precioVenta oficial de la pantalla
        const precioAplicado = item.precioUnitario ?? Number(pantalla.precioVenta);
        const subtotal = Number((item.cantidad * precioAplicado).toFixed(2));
        totalVenta += subtotal;

        const detalle = new DetalleVenta();
        detalle.idVenta = ventaGuardada.id;
        detalle.idPantalla = item.idPantalla;
        detalle.cantidad = item.cantidad;
        detalle.precioUnitario = precioAplicado;
        detalle.subtotal = subtotal;
        await queryRunner.manager.save(DetalleVenta, detalle);
      }

      ventaGuardada.total = Number(totalVenta.toFixed(2));
      await queryRunner.manager.save(Venta, ventaGuardada);

      await queryRunner.commitTransaction();
      return this.findOne(ventaGuardada.id);
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  async findAll(): Promise<Venta[]> {
    return this.ventasRepository.find({
      relations: {
        usuario: true,
        almacen: true,
        detalles: { pantalla: true },
      },
      order: { id: 'DESC' },
    });
  }

  async findOne(id: number): Promise<Venta> {
    const venta = await this.ventasRepository.findOne({
      where: { id },
      relations: {
        usuario: true,
        almacen: true,
        detalles: { pantalla: true },
      },
    });
    if (!venta) throw new NotFoundException('La venta no existe');
    return venta;
  }

  async update(id: number, updateVentaDto: UpdateVentaDto): Promise<Venta> {
    const venta = await this.findOne(id);
    Object.assign(venta, updateVentaDto);
    return this.ventasRepository.save(venta);
  }

  async remove(id: number): Promise<Venta> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const venta = await this.findOne(id);

      // Devolver las pantallas al inventario al eliminar/anular la venta
      for (const detalle of venta.detalles) {
        let inventario = await queryRunner.manager.findOneBy(InventarioAlmacen, {
          idPantalla: detalle.idPantalla,
          idAlmacen: venta.idAlmacen,
        });

        if (!inventario) {
          inventario = new InventarioAlmacen();
          inventario.idPantalla = detalle.idPantalla;
          inventario.idAlmacen = venta.idAlmacen;
          inventario.cantidad = detalle.cantidad;
        } else {
          inventario.cantidad += detalle.cantidad;
        }

        await queryRunner.manager.save(InventarioAlmacen, inventario);
      }

      const eliminada = await queryRunner.manager.softRemove(Venta, venta);
      await queryRunner.commitTransaction();
      return eliminada;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
